import { Component } from '@angular/core';

@Component({
  selector: 'app-dailyexpence',
  templateUrl: './dailyexpence.component.html',
  styleUrl: './dailyexpence.component.css'
})
export class DailyexpenceComponent {

}
