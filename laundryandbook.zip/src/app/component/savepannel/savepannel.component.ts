import { Component } from '@angular/core';

@Component({
  selector: 'app-savepannel',
  templateUrl: './savepannel.component.html',
  styleUrl: './savepannel.component.css'
})
export class SavepannelComponent {

}
