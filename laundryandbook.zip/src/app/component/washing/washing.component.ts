import { Component } from '@angular/core';

@Component({
  selector: 'app-washing',
  templateUrl: './washing.component.html',
  styleUrl: './washing.component.css'
})
export class WashingComponent {

}
