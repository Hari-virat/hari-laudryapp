import { Component } from '@angular/core';

@Component({
  selector: 'app-monthlyexpence',
  templateUrl: './monthlyexpence.component.html',
  styleUrl: './monthlyexpence.component.css'
})
export class MonthlyexpenceComponent {

}
