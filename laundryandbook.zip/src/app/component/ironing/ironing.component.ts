import { Component } from '@angular/core';

@Component({
  selector: 'app-ironing',
  templateUrl: './ironing.component.html',
  styleUrl: './ironing.component.css'
})
export class IroningComponent {

}
