import { Component } from '@angular/core';

@Component({
  selector: 'app-createexpence',
  templateUrl: './createexpence.component.html',
  styleUrl: './createexpence.component.css'
})
export class CreateexpenceComponent {

}
