import { Component } from '@angular/core';

@Component({
  selector: 'app-customerhistory',
  templateUrl: './customerhistory.component.html',
  styleUrl: './customerhistory.component.css'
})
export class CustomerhistoryComponent {

}
