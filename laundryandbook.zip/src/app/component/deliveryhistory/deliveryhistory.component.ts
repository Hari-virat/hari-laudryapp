import { Component } from '@angular/core';

@Component({
  selector: 'app-deliveryhistory',
  templateUrl: './deliveryhistory.component.html',
  styleUrl: './deliveryhistory.component.css'
})
export class DeliveryhistoryComponent {

}
